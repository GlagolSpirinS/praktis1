from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import render, get_object_or_404, redirect

from .forms import UserCreationFormCustom, TaskForm
from .models import User, Department, Task


def staff(request):
    departments = Department.objects.all()
    return render(request, 'staff/staff.html', {'departments': departments})

@login_required
def profile(request):
    return render(request, 'profile/profile.html', {'user': request.user})

@login_required
def my_tasks(request):
    if not request.user.is_authenticated:
        messages.error(request, 'У тебя нет доступа к этой странице.')
        return HttpResponseForbidden('У тебя нет доступа к этой странице.')

    tasks = Task.objects.filter(assigned_to=request.user).order_by('-created_at')
    return render(request, 'tasks/tasks.html', {'tasks': tasks})

def user_profile(request, user_id):
    user = get_object_or_404(User, id=user_id)
    return render(request, 'user_profile.html', {'user': user})

def register(request):
    if request.method == 'POST':
        form = UserCreationFormCustom(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Авторизуем пользователя после регистрации
            return redirect('home')  # Перенаправляем на главную страницу (можно изменить на другую страницу)
    else:
        form = UserCreationFormCustom()

    return render(request, 'register/register.html', {'form': form})


@login_required
def create_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)  # Сохраняем без сохранения в БД
            # Проверяем и сохраняем пользователя из формы
            task.assigned_to = form.cleaned_data['assigned_to']
            task.save()  # Сохраняем задание в БД
            return redirect('my_tasks')  # Перенаправление после создания задания
    else:
        form = TaskForm()
    return render(request, 'create_task/create_task.html', {'form': form})
