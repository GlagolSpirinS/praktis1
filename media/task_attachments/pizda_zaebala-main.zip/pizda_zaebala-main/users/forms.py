from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Department, Task

class UserCreationFormCustom(UserCreationForm):
    gender_choices = User.GENDER_CHOICES
    shift_choices = User.SHIFT_CHOICES
    position_choices = User.POSITION_CHOICES

    gender = forms.ChoiceField(choices=gender_choices, required=False, label="Пол")
    department = forms.ModelChoiceField(queryset=Department.objects.all(), required=False, label="Отдел")
    position = forms.ChoiceField(choices=position_choices, required=False, label="Должность")
    shift = forms.ChoiceField(choices=shift_choices, required=False, label="Смена")
    avatar = forms.ImageField(required=False, label="Аватар")

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'gender', 'department', 'position', 'shift', 'avatar')



class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'status', 'assigned_to']
        widgets = {
                'description': forms.Textarea(attrs={
                    'class': 'form-control',  # Добавляем класс для Bootstrap
                    'rows': 4,
                    'aria-label': 'With textarea'  # Для соответствия вашему примеру
                }),
                'title': forms.TextInput(attrs={
                    'class': 'form-control'
                }),
                'status': forms.Select(attrs={
                    'class': 'form-control'
                }),
                'assigned_to': forms.Select(attrs={
                    'class': 'form-control'
                })
            }

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            # Фильтруем пользователей (например, только активные)
            self.fields['assigned_to'].queryset = User.objects.filter(is_active=True)