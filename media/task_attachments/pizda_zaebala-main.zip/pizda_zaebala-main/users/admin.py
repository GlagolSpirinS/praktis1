from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User, Task, Department, FileComment, TaskAttachment

# Регистрируем модель User в админке
admin.site.register(User)
admin.site.register(Task)
admin.site.register(Department)
admin.site.register(FileComment)
admin.site.register(TaskAttachment)