function toggleDepartment(element) {
    const usersList = element.nextElementSibling;
    if (usersList.style.display === "none") {
        usersList.style.display = "block";
        usersList.style.maxHeight = usersList.scrollHeight + "px";
    } else {
        usersList.style.maxHeight = "0";
        setTimeout(() => {
            usersList.style.display = "none";
        }, 300); // Время анимации в миллисекундах
    }
}