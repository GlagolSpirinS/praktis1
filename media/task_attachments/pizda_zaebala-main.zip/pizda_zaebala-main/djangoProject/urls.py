from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from django.conf.urls.static import static
from django.conf import settings

from users import views

urlpatterns = [
    path('', TemplateView.as_view(template_name='home.html'), name='home'),

    path('my-tasks/', views.my_tasks, name='my_tasks'),

    path('register/', views.register, name='register'),

    path('create-task/', views.create_task, name='create_task'),

    path('staff/', views.staff, name='staff'),
    path('profile/', views.profile, name='profile'),
    path('user/<int:user_id>/', views.user_profile, name='user_profile'),
    path('admin/', admin.site.urls),

    path('users/', include('users.urls')),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)